//
//  FoodMinder.swift
//  foodMinder
//
//  Created by Brandi on 10/23/19.
//  Copyright © 2019 Brandi. All rights reserved.
//

import Foundation

struct FoodMinder: Codable, Equatable, Comparable {
    
    let title: String
    let identifier: String
    let body: String
    var isActive: Bool

}
